import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { CartProvider } from './contexts/CartContext'
import Navigation from './components/Navigation'
import Home from './pages/Home'
import CartPage from './pages/CartPage'
import Contact from './pages/Contact'
import Wishlist from './pages/Wishlist'
import Footer from './components/Footer'
import FloatingCartButton from './components/FloatingCartButton'

function App() {
  return (
    <CartProvider>
      <Router>
        <div className="app">
          <Navigation />
          <main className="page-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/cart" element={<CartPage />} />
              <Route path="/wishlist" element={<Wishlist />} />
              <Route path="/contact" element={<Contact />} />
            </Routes>
          </main>
          <FloatingCartButton />
          <Footer />
        </div>
      </Router>
    </CartProvider>
  )
}

export default App
