import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { fetchProducts } from '../utils/api';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem, items } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);

  useEffect(() => {
    const loadProduct = async () => {
      try {
        const products = await fetchProducts();
        const foundProduct = products.find(p => p.id === parseInt(id));
        if (foundProduct) {
          setProduct(foundProduct);
          // Track recently viewed
          const recentlyViewed = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
          const filtered = recentlyViewed.filter(item => item.id !== foundProduct.id);
          filtered.unshift(foundProduct);
          localStorage.setItem('recentlyViewed', JSON.stringify(filtered.slice(0, 8)));
        }
      } catch (error) {
        console.error('Error loading product:', error);
      } finally {
        setLoading(false);
      }
    };

    loadProduct();
  }, [id]);

  const handleAddToCart = () => {
    if (product) {
      addItem(product);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={i} className="star filled">★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half" className="star half">★</span>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
    }

    return stars;
  };

  if (loading) {
    return (
      <div className="product-detail-page">
        <div className="container">
          <div className="loading">Loading product...</div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="product-detail-page">
        <div className="container">
          <div className="error">
            <h2>Product not found</h2>
            <button onClick={() => navigate('/')} className="back-btn">
              ← Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  const cartItem = items.find(item => item.id === product.id);
  const isInCart = !!cartItem;
  const canAddMore = !isInCart || cartItem.quantity < product.stock;

  return (
    <div className="product-detail-page">
      <div className="container">
        <button onClick={() => navigate('/')} className="back-btn">
          ← Back to Products
        </button>

        <div className="product-detail-content">
          <div className="product-images">
            <div className="main-image">
              <img
                src={product.images[selectedImage]}
                alt={product.title}
                onError={(e) => {
                  e.target.src = product.images[0] || '/placeholder-image.jpg';
                }}
              />
            </div>
            {product.images.length > 1 && (
              <div className="image-thumbnails">
                {product.images.slice(0, 4).map((image, index) => (
                  <img
                    key={index}
                    src={image}
                    alt={`${product.title} ${index + 1}`}
                    className={selectedImage === index ? 'active' : ''}
                    onClick={() => setSelectedImage(index)}
                    onError={(e) => {
                      e.target.style.display = 'none';
                    }}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="product-info">
            <div className="product-header">
              <h1>{product.title}</h1>
              <div className="product-rating">
                {renderStars(product.rating)}
                <span className="rating-text">({product.rating})</span>
              </div>
            </div>

            <div className="product-price">
              <span className="price">${product.price}</span>
              <span className="category">{product.category}</span>
            </div>

            <div className="product-stock">
              <span className={`stock-status ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
                {product.stock > 0 ? `✓ In Stock (${product.stock} available)` : '✗ Out of Stock'}
              </span>
            </div>

            <div className="product-description">
              <h3>Description</h3>
              <p>{product.description}</p>
            </div>

            <div className="product-meta">
              <div className="meta-item">
                <strong>Brand:</strong> {product.brand || 'N/A'}
              </div>
              <div className="meta-item">
                <strong>SKU:</strong> {product.sku || product.id}
              </div>
              <div className="meta-item">
                <strong>Weight:</strong> {product.weight || 'N/A'}g
              </div>
              <div className="meta-item">
                <strong>Dimensions:</strong>
                {product.dimensions ? `${product.dimensions.width} × ${product.dimensions.height} × ${product.dimensions.depth} cm` : 'N/A'}
              </div>
            </div>

            <div className="product-tags">
              <h4>Tags:</h4>
              <div className="tags-list">
                {product.tags?.map((tag, index) => (
                  <span key={index} className="tag">{tag}</span>
                )) || <span className="tag">{product.category}</span>}
              </div>
            </div>

            <div className="product-actions">
              <button
                className="add-to-cart-btn"
                onClick={handleAddToCart}
                disabled={!canAddMore}
              >
                {isInCart ? `Add More (${cartItem.quantity} in cart)` : 'Add to Cart'}
              </button>
              <button className="wishlist-btn" onClick={() => navigate('/wishlist')}>
                ❤️ View Wishlist
              </button>
            </div>
          </div>
        </div>

        {/* Related Products Section could go here */}
      </div>
    </div>
  );
};

export default ProductDetail;