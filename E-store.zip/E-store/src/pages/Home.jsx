import ProductList from '../components/ProductList';
import RecentlyViewed from '../components/RecentlyViewed';
import HeroSection from '../components/HeroSection';

const Home = () => {
  return (
    <div className="home-page">
      <HeroSection />
      <ProductList />
      <RecentlyViewed />
    </div>
  );
};

export default Home;