import { useCart } from '../contexts/CartContext';
import { Link } from 'react-router-dom';

const Wishlist = () => {
  const { wishlist, toggleWishlist, addItem, items } = useCart();

  const isInCart = (productId) => {
    return items.some(item => item.id === productId);
  };

  if (wishlist.length === 0) {
    return (
      <div className="wishlist-page empty-wishlist">
        <div className="empty-wishlist-content">
          <div className="empty-wishlist-icon">💝</div>
          <h2>Your wishlist is empty</h2>
          <p>Save items you love for later! Start browsing and add items to your wishlist.</p>
          <Link to="/" className="continue-shopping-btn">
            Start Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="wishlist-page">
      <div className="wishlist-header">
        <h1>My Wishlist ({wishlist.length} items)</h1>
        <p>Items you've saved for later</p>
      </div>

      <div className="wishlist-grid">
        {wishlist.map(product => (
          <div key={product.id} className="wishlist-item">
            <div className="wishlist-item-image">
              <img src={product.images[0]} alt={product.title} />
              <button
                className="remove-wishlist-btn"
                onClick={() => toggleWishlist(product)}
                title="Remove from wishlist"
              >
                ✕
              </button>
            </div>

            <div className="wishlist-item-info">
              <h3>{product.title}</h3>
              <p className="wishlist-item-price">${product.price}</p>
              <p className="wishlist-item-category">{product.category}</p>
              <div className="wishlist-item-rating">
                {'★'.repeat(Math.floor(product.rating))}
                <span className="rating-text">({product.rating})</span>
              </div>
              <p className={`wishlist-item-stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
                {product.stock > 0 ? 'In Stock' : 'Out of Stock'}
              </p>
            </div>

            <div className="wishlist-item-actions">
              <button
                className="add-to-cart-from-wishlist"
                onClick={() => addItem(product)}
                disabled={isInCart(product.id)}
              >
                {isInCart(product.id) ? 'Already in Cart' : 'Add to Cart'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Wishlist;