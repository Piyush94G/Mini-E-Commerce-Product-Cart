import { useCart } from '../contexts/CartContext';

const Cart = () => {
  const { items, removeItem, updateQuantity, getTotalItems, getTotalPrice, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="cart">
        <h2>Cart</h2>
        <p>Your cart is empty</p>
      </div>
    );
  }

  return (
    <div className="cart">
      <h2>Cart ({getTotalItems()} items)</h2>
      <div className="cart-items">
        {items.map(item => (
          <div key={item.id} className="cart-item">
            <div className="cart-item-info">
              <h4>{item.title}</h4>
              <p>${item.price} each</p>
            </div>
            <div className="cart-item-controls">
              <button
                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                disabled={item.quantity <= 1}
              >
                -
              </button>
              <span>{item.quantity}</span>
              <button
                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                disabled={item.quantity >= item.stock}
              >
                +
              </button>
              <button onClick={() => removeItem(item.id)} className="remove-btn">
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>
      <div className="cart-total">
        <p>Total: ${getTotalPrice().toFixed(2)}</p>
        <button onClick={clearCart} className="clear-cart-btn">
          Clear Cart
        </button>
      </div>
    </div>
  );
};

export default Cart;