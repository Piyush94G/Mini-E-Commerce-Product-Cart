import { useCart } from '../contexts/CartContext';

const Header = () => {
  const { getTotalItems } = useCart();

  return (
    <header className="header">
      <div className="header-content">
        <div className="brand">
          <h1>ShopHub</h1>
          <span className="tagline">Quality Products, Great Prices</span>
        </div>
        <div className="cart-summary">
          <span className="cart-icon">🛒</span>
          Cart: {getTotalItems()} items
        </div>
      </div>
    </header>
  );
};

export default Header;