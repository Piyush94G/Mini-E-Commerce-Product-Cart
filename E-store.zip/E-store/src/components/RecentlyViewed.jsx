import { useState, useEffect } from 'react';
import ProductItem from './ProductItem';

const RecentlyViewed = () => {
  const [recentlyViewed, setRecentlyViewed] = useState([]);

  useEffect(() => {
    const viewed = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
    setRecentlyViewed(viewed.slice(0, 4)); // Show only last 4 viewed products
  }, []);

  if (recentlyViewed.length === 0) {
    return null;
  }

  return (
    <div className="recently-viewed">
      <h2>Recently Viewed</h2>
      <div className="recently-viewed-grid">
        {recentlyViewed.map(product => (
          <ProductItem key={`recent-${product.id}`} product={product} />
        ))}
      </div>
    </div>
  );
};

export default RecentlyViewed;