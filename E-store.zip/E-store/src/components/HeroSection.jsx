const HeroSection = () => {
  const scrollToProducts = () => {
    // Try multiple selectors to find the products section
    const selectors = ['.product-list-container', '.product-list', '[class*="product"]'];
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
    }
    // Fallback: scroll down by viewport height
    window.scrollTo({ top: window.innerHeight, behavior: 'smooth' });
  };

  return (
    <section className="hero-section">
      <div className="hero-background">
        <div className="hero-overlay"></div>
      </div>

      <div className="hero-content">
        <div className="hero-text">
          <div className="hero-badge">🏆 #1 Online Shopping Destination</div>
          <h1>Your Ultimate Shopping Experience</h1>
          <p className="hero-subtitle">
            Discover premium quality products from top brands at unbeatable prices.
            Free shipping on orders over $50. Shop with confidence.
          </p>

          <div className="hero-features">
            <div className="feature-item">
              <span className="feature-icon">🚚</span>
              <div className="feature-text">
                <strong>Free Shipping</strong>
                <small>On orders $50+</small>
              </div>
            </div>
            <div className="feature-item">
              <span className="feature-icon">🔒</span>
              <div className="feature-text">
                <strong>Secure Payment</strong>
                <small>100% Protected</small>
              </div>
            </div>
            <div className="feature-item">
              <span className="feature-icon">↩️</span>
              <div className="feature-text">
                <strong>Easy Returns</strong>
                <small>30-Day Policy</small>
              </div>
            </div>
          </div>

          <div className="hero-stats">
            <div className="stat">
              <span className="stat-number">15,000+</span>
              <span className="stat-label">Quality Products</span>
            </div>
            <div className="stat">
              <span className="stat-number">100,000+</span>
              <span className="stat-label">Happy Customers</span>
            </div>
            <div className="stat">
              <span className="stat-number">4.9★</span>
              <span className="stat-label">Customer Rating</span>
            </div>
            <div className="stat">
              <span className="stat-number">24/7</span>
              <span className="stat-label">Customer Support</span>
            </div>
          </div>

          <div className="hero-actions">
            <button className="hero-cta primary" onClick={scrollToProducts}>
              Start Shopping Now
            </button>
            <button className="hero-cta secondary" onClick={() => window.location.href = '/contact'}>
              Contact Us
            </button>
          </div>

          <div className="hero-trust">
            <span>Trusted by millions worldwide • Since 2020</span>
          </div>
        </div>

        <div className="hero-image">
          <div className="hero-product-showcase">
            <img
              src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=500&h=600&fit=crop&crop=center"
              alt="Fashion Model"
              className="featured-product"
            />

            <div className="product-badges">
              <div className="badge new">New Arrival</div>
              <div className="badge sale">-20% OFF</div>
            </div>

            <div className="floating-elements">
              <div className="floating-card card-1">
                <span>⚡</span>
                <small>Express Delivery</small>
              </div>
              <div className="floating-card card-2">
                <span>💎</span>
                <small>Premium Quality</small>
              </div>
              <div className="floating-card card-3">
                <span>🌟</span>
                <small>Top Rated</small>
              </div>
              <div className="floating-card card-4">
                <span>🎁</span>
                <small>Free Gifts</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="hero-scroll-indicator">
        <div className="scroll-text">Scroll to explore products</div>
        <div className="scroll-arrow">↓</div>
      </div>
    </section>
  );
};

export default HeroSection;