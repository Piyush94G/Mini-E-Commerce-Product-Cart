const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>E-Store</h3>
          <p>Your one-stop shop for quality products at great prices. We offer a wide range of items from electronics to fashion.</p>
        </div>
        <div className="footer-section">
          <h3>Quick Links</h3>
          <a href="#products">Products</a>
          <a href="#categories">Categories</a>
          <a href="#about">About Us</a>
          <a href="#contact">Contact</a>
        </div>
        <div className="footer-section">
          <h3>Customer Service</h3>
          <a href="#shipping">Shipping Info</a>
          <a href="#returns">Returns</a>
          <a href="#faq">FAQ</a>
          <a href="#support">Support</a>
        </div>
        <div className="footer-section">
          <h3>Connect With Us</h3>
          <p>Follow us on social media for the latest updates and deals.</p>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
            <span>📘</span>
            <span>🐦</span>
            <span>📷</span>
            <span>💼</span>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; 2024 E-Store. All rights reserved. | Made with ❤️ for shopping enthusiasts</p>
      </div>
    </footer>
  );
};

export default Footer;