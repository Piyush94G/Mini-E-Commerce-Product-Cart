import { useState, useEffect, useMemo } from 'react';
import ProductItem from './ProductItem';
import Filters from './Filters';
import LoadingSkeleton from './LoadingSkeleton';
import { fetchProducts } from '../utils/api';

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ search: '', category: '', sort: '' });

  useEffect(() => {
    const loadProducts = async () => {
      const data = await fetchProducts();
      setProducts(data);
      setLoading(false);
    };
    loadProducts();
  }, []);

  const categories = useMemo(() => {
    const uniqueCategories = [...new Set(products.map(p => p.category))];
    return uniqueCategories;
  }, [products]);

  const filteredProducts = useMemo(() => {
    let filtered = products.filter(product => {
      const matchesSearch = product.title.toLowerCase().includes(filters.search.toLowerCase());
      const matchesCategory = !filters.category || product.category === filters.category;
      return matchesSearch && matchesCategory;
    });

    if (filters.sort === 'low-to-high') {
      filtered = filtered.sort((a, b) => a.price - b.price);
    } else if (filters.sort === 'high-to-low') {
      filtered = filtered.sort((a, b) => b.price - a.price);
    } else if (filters.sort === 'rating-high') {
      filtered = filtered.sort((a, b) => b.rating - a.rating);
    } else if (filters.sort === 'rating-low') {
      filtered = filtered.sort((a, b) => a.rating - b.rating);
    }

    return filtered;
  }, [products, filters]);

  if (loading) {
    return (
      <div className="product-list-container">
        <Filters onFiltersChange={setFilters} categories={[]} />
        <div className="product-list">
          {Array.from({ length: 12 }, (_, index) => (
            <LoadingSkeleton key={index} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="product-list-container">
      <Filters onFiltersChange={setFilters} categories={categories} />
      {filteredProducts.length === 0 ? (
        <div className="no-products">No products found</div>
      ) : (
        <div className="product-list">
          {filteredProducts.map(product => (
            <ProductItem key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductList;