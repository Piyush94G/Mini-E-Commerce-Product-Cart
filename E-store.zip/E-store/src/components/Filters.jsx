import { useState, useEffect } from 'react';
import { useDebounce } from '../hooks/useDebounce';

const Filters = ({ onFiltersChange, categories }) => {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [sort, setSort] = useState('');

  const debouncedSearch = useDebounce(search, 300);

  useEffect(() => {
    onFiltersChange({ search: debouncedSearch, category, sort });
  }, [debouncedSearch, category, sort, onFiltersChange]);

  const clearFilters = () => {
    setSearch('');
    setCategory('');
    setSort('');
  };

  return (
    <div className="filters">
      <input
        type="text"
        placeholder="Search products..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="search-input"
      />
      <select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
        className="category-select"
      >
        <option value="">All Categories</option>
        {categories.map(cat => (
          <option key={cat} value={cat}>{cat}</option>
        ))}
      </select>
      <select
        value={sort}
        onChange={(e) => setSort(e.target.value)}
        className="sort-select"
      >
        <option value="">Sort by</option>
        <option value="low-to-high">Price: Low to High</option>
        <option value="high-to-low">Price: High to Low</option>
        <option value="rating-high">Rating: High to Low</option>
        <option value="rating-low">Rating: Low to High</option>
      </select>
      <button onClick={clearFilters} className="clear-filters-btn">
        Clear Filters
      </button>
    </div>
  );
};

export default Filters;