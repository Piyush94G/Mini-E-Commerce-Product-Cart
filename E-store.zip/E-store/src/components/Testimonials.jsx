const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Fashion Enthusiast",
      content: "E-Store has the best collection of trendy clothes. Fast delivery and excellent customer service!",
      rating: 5,
      avatar: "👩‍💼"
    },
    {
      name: "Mike Chen",
      role: "Tech Lover",
      content: "Amazing electronics selection with competitive prices. My go-to online store for gadgets!",
      rating: 5,
      avatar: "👨‍💻"
    },
    {
      name: "Emma Davis",
      role: "Home Decor Expert",
      content: "Beautiful home decor items at great prices. The quality exceeded my expectations.",
      rating: 5,
      avatar: "👩‍🎨"
    }
  ];

  const renderStars = (rating) => {
    return '★'.repeat(rating);
  };

  return (
    <section className="testimonials-section">
      <div className="testimonials-container">
        <div className="testimonials-header">
          <h2>What Our Customers Say</h2>
          <p>Join thousands of satisfied customers who trust E-Store for their shopping needs</p>
        </div>

        <div className="testimonials-grid">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="testimonial-card">
              <div className="testimonial-rating">
                {renderStars(testimonial.rating)}
              </div>
              <div className="testimonial-content">
                <p>"{testimonial.content}"</p>
              </div>
              <div className="testimonial-author">
                <div className="author-avatar">
                  {testimonial.avatar}
                </div>
                <div className="author-info">
                  <h4>{testimonial.name}</h4>
                  <span>{testimonial.role}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="trust-indicators">
          <div className="trust-item">
            <div className="trust-icon">🔒</div>
            <div className="trust-text">
              <h4>Secure Payments</h4>
              <p>100% secure checkout process</p>
            </div>
          </div>
          <div className="trust-item">
            <div className="trust-icon">🚚</div>
            <div className="trust-text">
              <h4>Free Shipping</h4>
              <p>On orders over $50</p>
            </div>
          </div>
          <div className="trust-item">
            <div className="trust-icon">↩️</div>
            <div className="trust-text">
              <h4>Easy Returns</h4>
              <p>30-day return policy</p>
            </div>
          </div>
          <div className="trust-item">
            <div className="trust-icon">🎯</div>
            <div className="trust-text">
              <h4>Quality Guarantee</h4>
              <p>Authentic products only</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;