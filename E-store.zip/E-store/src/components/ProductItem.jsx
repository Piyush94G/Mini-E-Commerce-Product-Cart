import { useState } from 'react';
import { useCart } from '../contexts/CartContext';
import ProductModal from './ProductModal';

const ProductItem = ({ product }) => {
  const { addItem, items, toggleWishlist, isInWishlist } = useCart();
  const [showModal, setShowModal] = useState(false);
  const cartItem = items.find(item => item.id === product.id);
  const isInCart = !!cartItem;
  const MAX_QUANTITY_PER_PRODUCT = 5;
  const canAddMore = product.stock > 0 && (!isInCart || cartItem.quantity < Math.min(product.stock, MAX_QUANTITY_PER_PRODUCT));
  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = () => {
    if (canAddMore) {
      addItem(product);
    }
  };

  const handleQuickView = () => {
    setShowModal(true);
    handleProductClick();
  };

  const handleProductClick = () => {
    // Track recently viewed products
    const recentlyViewed = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
    const filtered = recentlyViewed.filter(item => item.id !== product.id);
    filtered.unshift(product);
    localStorage.setItem('recentlyViewed', JSON.stringify(filtered.slice(0, 8))); // Keep last 8
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={i} className="star filled">★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half" className="star half">★</span>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
    }

    return stars;
  };

  return (
    <div className="product-item">
      <div className="product-image">
        <img src={product.images[0]} alt={product.title} />
        <div className="product-actions">
          <button className="quick-view-btn" title="Quick View" onClick={handleQuickView}>👁️</button>
          <button
            className={`wishlist-btn ${inWishlist ? 'active' : ''}`}
            title={inWishlist ? "Remove from Wishlist" : "Add to Wishlist"}
            onClick={() => toggleWishlist(product)}
          >
            {inWishlist ? '❤️' : '🤍'}
          </button>
        </div>
      </div>
      <div className="product-info">
        <h3>{product.title}</h3>
        <div className="rating">
          {renderStars(product.rating)}
          <span className="rating-text">({product.rating})</span>
        </div>
        <p className="price">${product.price}</p>
        <p className="category">{product.category}</p>
        <p className={`stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
          {product.stock > 0 ? `In stock (max ${MAX_QUANTITY_PER_PRODUCT} per customer)` : 'Out of stock'}
        </p>
        <button
          onClick={handleAddToCart}
          disabled={!canAddMore}
          className="add-to-cart-btn"
        >
          {product.stock === 0
            ? 'Out of Stock'
            : isInCart && cartItem.quantity >= Math.min(product.stock, MAX_QUANTITY_PER_PRODUCT)
            ? `Limit Reached (${MAX_QUANTITY_PER_PRODUCT})`
            : isInCart
            ? 'Add More'
            : 'Add to Cart'
          }
        </button>
      </div>

      {showModal && (
        <ProductModal
          product={product}
          onClose={() => setShowModal(false)}
        />
      )}
    </div>
  );
};

export default ProductItem;