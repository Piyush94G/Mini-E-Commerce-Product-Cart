import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';

const FloatingCartButton = () => {
  const { getTotalItems } = useCart();

  if (getTotalItems() === 0) {
    return null;
  }

  return (
    <Link to="/cart" className="floating-cart-btn">
      <span className="cart-count">{getTotalItems()}</span>
      <span className="cart-text">View Cart</span>
    </Link>
  );
};

export default FloatingCartButton;