import { useEffect } from 'react';
import { useCart } from '../contexts/CartContext';

const ProductModal = ({ product, onClose }) => {
  const { addItem, items } = useCart();
  const cartItem = items.find(item => item.id === product.id);
  const isInCart = !!cartItem;
  const MAX_QUANTITY_PER_PRODUCT = 5;
  const canAddMore = product.stock > 0 && (!isInCart || cartItem.quantity < Math.min(product.stock, MAX_QUANTITY_PER_PRODUCT));

  const handleAddToCart = () => {
    if (canAddMore) {
      addItem(product);
    }
  };

  const renderStars = (rating) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={i} className="star filled">★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half" className="star half">★</span>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
    }

    return stars;
  };

  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [onClose]);

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className="modal-backdrop" onClick={handleBackdropClick}>
      <div className="modal-content">
        <button className="modal-close" onClick={onClose}>×</button>

        <div className="modal-body">
          <div className="modal-image">
            <img src={product.images[0]} alt={product.title} />
          </div>

          <div className="modal-details">
            <h2>{product.title}</h2>

            <div className="modal-rating">
              {renderStars(product.rating)}
              <span className="rating-text">({product.rating})</span>
            </div>

            <p className="modal-price">${product.price}</p>

            <p className="modal-category">
              <strong>Category:</strong> {product.category}
            </p>

            <p className={`modal-stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
              {product.stock > 0 ? `In Stock (${product.stock} available, max ${MAX_QUANTITY_PER_PRODUCT} per customer)` : 'Out of Stock'}
            </p>

            <div className="modal-description">
              <h4>Description</h4>
              <p>{product.description}</p>
              {product.tags && product.tags.length > 0 && (
                <div className="modal-tags">
                  <strong>Tags:</strong>
                  <div className="tags-list">
                    {product.tags.map((tag, index) => (
                      <span key={index} className="tag">{tag}</span>
                    ))}
                  </div>
                </div>
              )}
              <div className="modal-meta">
                <div className="meta-item">
                  <strong>Brand:</strong> {product.brand || 'N/A'}
                </div>
                <div className="meta-item">
                  <strong>Weight:</strong> {product.weight ? `${product.weight}g` : 'N/A'}
                </div>
                <div className="meta-item">
                  <strong>Dimensions:</strong> {product.dimensions ? `${product.dimensions.width} × ${product.dimensions.height} × ${product.dimensions.depth} cm` : 'N/A'}
                </div>
              </div>
            </div>

            <div className="modal-actions">
              <button
                className="modal-add-to-cart"
                onClick={handleAddToCart}
                disabled={!canAddMore}
              >
                {product.stock === 0
                  ? 'Out of Stock'
                  : isInCart && cartItem.quantity >= Math.min(product.stock, MAX_QUANTITY_PER_PRODUCT)
                  ? `Limit Reached (${MAX_QUANTITY_PER_PRODUCT})`
                  : isInCart
                  ? 'Add More to Cart'
                  : 'Add to Cart'
                }
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;