const LoadingSkeleton = () => {
  return (
    <div className="product-item skeleton">
      <div className="product-image skeleton-image"></div>
      <div className="product-info">
        <div className="skeleton-title"></div>
        <div className="skeleton-rating"></div>
        <div className="skeleton-price"></div>
        <div className="skeleton-category"></div>
        <div className="skeleton-stock"></div>
        <div className="skeleton-button"></div>
      </div>
    </div>
  );
};

export default LoadingSkeleton;