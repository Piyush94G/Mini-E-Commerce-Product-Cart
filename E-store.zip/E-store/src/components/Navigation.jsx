import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';

const Navigation = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { getTotalItems, wishlist } = useCart();
  const location = useLocation();

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <>
      {/* Desktop Header */}
      <header className="desktop-header">
        <div className="header-content">
          <Link to="/" className="logo" onClick={closeMobileMenu}>
            <span className="logo-icon">🛍️</span>
            <span className="logo-text">E-Store</span>
          </Link>

          <nav className="desktop-nav">
            <Link to="/" className={`nav-link ${isActive('/') ? 'active' : ''}`}>
              Home
            </Link>
            <Link to="/cart" className={`nav-link ${isActive('/cart') ? 'active' : ''}`}>
              Cart {getTotalItems() > 0 && <span className="cart-badge">{getTotalItems()}</span>}
            </Link>
            <Link to="/wishlist" className={`nav-link ${isActive('/wishlist') ? 'active' : ''}`}>
              Wishlist {wishlist.length > 0 && <span className="wishlist-badge">{wishlist.length}</span>}
            </Link>
            <Link to="/contact" className={`nav-link ${isActive('/contact') ? 'active' : ''}`}>
              Contact
            </Link>
          </nav>

          <button className="mobile-menu-toggle" onClick={toggleMobileMenu}>
            <span className="hamburger-line"></span>
            <span className="hamburger-line"></span>
            <span className="hamburger-line"></span>
          </button>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="mobile-menu-overlay" onClick={closeMobileMenu}>
          <nav className="mobile-menu">
            <div className="mobile-menu-header">
              <span className="mobile-logo">🛍️ E-Store</span>
              <button className="mobile-menu-close" onClick={closeMobileMenu}>×</button>
            </div>

            <div className="mobile-menu-links">
              <Link to="/" className={`mobile-nav-link ${isActive('/') ? 'active' : ''}`} onClick={closeMobileMenu}>
                Home
              </Link>
              <Link to="/cart" className={`mobile-nav-link ${isActive('/cart') ? 'active' : ''}`} onClick={closeMobileMenu}>
                Cart {getTotalItems() > 0 && <span className="cart-badge">{getTotalItems()}</span>}
              </Link>
              <Link to="/wishlist" className={`mobile-nav-link ${isActive('/wishlist') ? 'active' : ''}`} onClick={closeMobileMenu}>
                Wishlist {wishlist.length > 0 && <span className="wishlist-badge">{wishlist.length}</span>}
              </Link>
              <Link to="/contact" className={`mobile-nav-link ${isActive('/contact') ? 'active' : ''}`} onClick={closeMobileMenu}>
                Contact
              </Link>
            </div>
          </nav>
        </div>
      )}

      {/* Mobile Bottom Navigation */}
      <nav className="mobile-bottom-nav">
        <Link to="/" className={`bottom-nav-item ${isActive('/') ? 'active' : ''}`}>
          <span className="bottom-nav-icon">🏠</span>
          <span className="bottom-nav-text">Home</span>
        </Link>

        <Link to="/cart" className={`bottom-nav-item ${isActive('/cart') ? 'active' : ''}`}>
          <span className="bottom-nav-icon">🛒</span>
          <span className="bottom-nav-text">Cart</span>
          {getTotalItems() > 0 && <span className="cart-badge">{getTotalItems()}</span>}
        </Link>

        <Link to="/wishlist" className={`bottom-nav-item ${isActive('/wishlist') ? 'active' : ''}`}>
          <span className="bottom-nav-icon">❤️</span>
          <span className="bottom-nav-text">Wishlist</span>
          {wishlist.length > 0 && <span className="wishlist-badge">{wishlist.length}</span>}
        </Link>

        <Link to="/contact" className={`bottom-nav-item ${isActive('/contact') ? 'active' : ''}`}>
          <span className="bottom-nav-icon">📞</span>
          <span className="bottom-nav-text">Contact</span>
        </Link>
      </nav>
    </>
  );
};

export default Navigation;